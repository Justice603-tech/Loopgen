# Loopgen

Loopgen is a **PYTHON** Module designed for generating loops in diffrent *styles*

These styles are: 
* Stargen:
  * Right angle
* Sequenced Gen(Number generation):
  * Right Angle
  * Left Angle


Currently only **2** styles here. but more will be coming!